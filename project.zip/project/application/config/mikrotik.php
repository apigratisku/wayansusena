<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['hostname_mikrotik'] = '10.10.10.254';
$config['username_mikrotik'] = 'admin';
$config['password_mikrotik'] = '';