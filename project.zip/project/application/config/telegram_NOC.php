<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

$config['bot_token'] = '1117257670:AAHlAgCIfzL3DTe4xnI8ygVdVVpr2z9JDls';
//$config['chat_id'] = '-1001499615009';
$config['chat_id'] = '250170651';

