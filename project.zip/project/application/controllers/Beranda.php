<?php

class Beranda extends CI_Controller {

    public function __construct() {
        parent::__construct();

        /*
        $this->load->model('member_model');
        $this->load->model('tukang_model');
        $this->load->model('pekerjaan_model');
        $this->load->model('toko_model');
        */
    }

    public function index() {
        if (!file_exists(APPPATH.'views/backend/login.php')) {
            show_404();
        }
		
        $this->load->view('backend/login');
    }


}
